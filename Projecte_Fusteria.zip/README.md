# Gestió de Fusteria

Projecte modular per gestionar una empresa de fusteria amb funcionalitats completes:
- Facturació
- Comptabilitat
- Gestió laboral
- Seguiment de tasques
- Estadístiques

Tot el projecte està escrit en català i estructurat per mòduls independents.
