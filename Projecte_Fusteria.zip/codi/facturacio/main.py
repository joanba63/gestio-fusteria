# Mòdul de Facturació
# Aquest fitxer és el punt d'entrada per gestionar les factures dels clients.

def crear_factura():
    print("Funció per crear una nova factura")

if __name__ == "__main__":
    crear_factura()
